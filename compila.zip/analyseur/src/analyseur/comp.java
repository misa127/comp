
package analyseur;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;


public class comp extends javax.swing.JFrame {

    
    static JFileChooser file_chooser = new JFileChooser();
	static FileNameExtensionFilter filter = new FileNameExtensionFilter("Fichiers text", "compila");
	static ArrayList<String> mots = new ArrayList<String>();
	static ArrayList<String> lignes = new ArrayList<String>();
	static ArrayList<String> sortie_lexic = new ArrayList<String>();
	static String[] mot;
    public comp() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TEXT4 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        TEXT1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        TEXT2 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        TEXT3 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setLayout(null);

        jButton1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jButton1.setText("semantique");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setMaximumSize(new java.awt.Dimension(135, 27));
        jButton1.setMinimumSize(new java.awt.Dimension(135, 27));
        jButton1.setPreferredSize(new java.awt.Dimension(200, 40));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(1060, 20, 240, 70);

        jButton5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jButton5.setText("Charger Fichier");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.setPreferredSize(new java.awt.Dimension(200, 40));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(30, 20, 230, 70);

        jButton6.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jButton6.setText("lexical");
        jButton6.setBorder(new javax.swing.border.MatteBorder(null));
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setMaximumSize(new java.awt.Dimension(135, 27));
        jButton6.setMinimumSize(new java.awt.Dimension(135, 27));
        jButton6.setPreferredSize(new java.awt.Dimension(200, 40));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6);
        jButton6.setBounds(330, 20, 250, 70);

        jButton7.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jButton7.setText("syntaxique");
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.setMaximumSize(new java.awt.Dimension(135, 27));
        jButton7.setMinimumSize(new java.awt.Dimension(135, 27));
        jButton7.setPreferredSize(new java.awt.Dimension(200, 40));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7);
        jButton7.setBounds(690, 20, 240, 70);

        TEXT4.setEditable(false);
        TEXT4.setColumns(50);
        TEXT4.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        TEXT4.setRows(200);
        TEXT4.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red), javax.swing.BorderFactory.createLineBorder(java.awt.Color.red)));
        jScrollPane1.setViewportView(TEXT4);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(1010, 100, 350, 590);

        TEXT1.setEditable(false);
        TEXT1.setColumns(50);
        TEXT1.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        TEXT1.setRows(200);
        TEXT1.setTabSize(5);
        TEXT1.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red), javax.swing.BorderFactory.createLineBorder(java.awt.Color.red)));
        jScrollPane2.setViewportView(TEXT1);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(0, 100, 280, 590);

        TEXT2.setEditable(false);
        TEXT2.setColumns(50);
        TEXT2.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        TEXT2.setRows(200);
        TEXT2.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red), javax.swing.BorderFactory.createLineBorder(java.awt.Color.red)));
        jScrollPane3.setViewportView(TEXT2);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(290, 100, 340, 590);

        TEXT3.setEditable(false);
        TEXT3.setColumns(50);
        TEXT3.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        TEXT3.setRows(200);
        TEXT3.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red), javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0))));
        jScrollPane4.setViewportView(TEXT3);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(640, 100, 360, 590);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 706, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       
						try {
							  TEXT1.setText("");
							charger();


							int i = 0;
							while (i < lignes.size()) {
								TEXT1.setText(TEXT1.getText()+lignes.get(i)+"\n");
								i++;}
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        TEXT2.setText("");
						lexicale(mots);
						int i = 0;
						while (i < mots.size()) {
							TEXT2.setText(TEXT2.getText()+mots.get(i) + " -> " + sortie_lexic.get(i)+"\n");
							i++;}
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        TEXT3.setText("");
						int i = 0;
						while (i < lignes.size()) {
							TEXT3.setText(TEXT3.getText()+lignes.get(i) + " -> " +syntax(lignes.get(i))+"\n");
							i++;}
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        TEXT4.setText("");
						int i = 0;
						
						
						while (i < lignes.size()) {
							TEXT4.setText(TEXT4.getText()+lignes.get(i) + " -> " +semantique(lignes.get(i))+"\n");
							
							i++;}
						
						i=0;
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new comp().setVisible(true);
            }
        });
    }
   public static void charger() throws FileNotFoundException {
		file_chooser.addChoosableFileFilter(filter);
		if(file_chooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
			File file = file_chooser.getSelectedFile();
                    try (Scanner sc_lignes = new Scanner(file); Scanner sc_mots = new Scanner(file)) {
                        mots.clear();
                        lignes.clear();
                        while(sc_lignes.hasNextLine()){
                            lignes.add(sc_lignes.nextLine());
                        }
                        while(sc_mots.hasNext()){
                            mots.add(sc_mots.next());
                        }
                        
                    }
			}
	}



	public boolean isNum(String chaine, int i) {
		char[] nombre = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
		int j = 0;
		while (j < nombre.length) {
			if (chaine.charAt(i) == nombre[j]) {
				return true;
			}
			j++;
		}

		return false;
	}

	public String num(String chaine) {
		int i = 0;
		int token_pos = 0;
		boolean point_unique = true;
		while (i < chaine.length()) {
			if (isNum(chaine, i)) token_pos++;
			else if(point_unique & chaine.charAt(token_pos)=='.') {
				token_pos++;
				point_unique = false;
			}
			i++;
		}

		if (token_pos == chaine.length() && !chaine.contains(".")) return "un entier";
		else if (token_pos == chaine.length() && !point_unique) return "un reel";
		return null;

	}



	public boolean isChar(String chaine, int i) {
		char[] alphabet = { 'A', 'a', 'B', 'b', 'C', 'c', 'D', 'd', 'E', 'e', 'F', 'f', 'G', 'g', 'H', 'h', 'I', 'i',
				'J', 'j', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'Q', 'q', 'R', 'r', 'S', 's', 'T',
				't', 'U', 'u', 'V', 'v', 'W', 'w', 'X', 'x', 'Y', 'y', 'Z', 'z' };
		int k = 0;
		while (k < alphabet.length) {
			if (chaine.charAt(i) == alphabet[k]) {
				return true;
			}
			k++;
		}
		return false;

	}

	public String id(String chaine) {
		boolean verifier_Premier = false;
		boolean tiret_unique = true;
		int token_pos = 0;
		int i = 0;
		if (isChar(chaine, 0)) {
			token_pos++;
			verifier_Premier = true;
		}
		if (verifier_Premier == true && chaine.length() == 1)
			return "identificateur";

		else if (chaine.length() > 1) {
			i = 1;
			while (i < chaine.length()) {

				if (isChar(chaine, i))
					{token_pos++;
					tiret_unique=true;
					}
				else if (isNum(chaine, i))
					{token_pos++;
					tiret_unique=true;
					}
				else if (chaine.charAt(i) == '_' && tiret_unique) {
					tiret_unique=true;
					token_pos++;
				}
				i++;
			}
			if (token_pos == chaine.length())
				return "Identificateur";
		}
		return null;
	}



	public String UL_reserve(String chaine) {
		
		String[] mot_reserve = {"\"","Start_Program", "Int_Number",";;","Give","Real_Number","If","--", "<",">","==", "Else",  "Start", "Affect","to","Finish",     
				 "ShowMes",  "ShowVal", "//.",",",":","While","Then","(",")","EndLoop","For", "End_Program" };

		String[] Affichage = {
                    " caractere reserve pour guiyume",
                    "Mot reserve debut du programme", " Mot reserve debut declaration d'un entier",
                    "Mot reserve fin instruction","Affectation d'une valeur à une variable",
                    " Mot reserve debut declaration d'un Real"," Mot reserve pour condition SI",
                    "Mot reserve pour condition","symbol inferieur","symbol superieur","symbol egale","Mot reserve pour condition SINON",
                    "Debut de bloc",
                    "Mot reserve pour affectation", "Mot reserve pour affectation entre variables",
                    "Fin de bloc",
                    "Mot reservé pour afficher un message "," Mot reservé pour afficher  une valeur",
                     "Mot reservé pour un commentaire","caractere reservé virgule",
                     "caractere reservé deux points","mot reserve pour boucle","mot reserve pour action de boucle","caractere reserve pour parenthese gauche","caractere reserve pour parenthese droite",
                     "mot reserve pour fin boucle","mot reserve pour boucle","Mot reserve Fin du programme"};
				
				
				
				
				
		int i = 0;
		while (i < mot_reserve.length) {
			if (chaine.equals(mot_reserve[i])) {
				return Affichage[i];
			}
			i++;
		}
		return null;
	}



	public String syntax(String chaine){
	
		if(chaine.equals("Start_Program")) return "Début du programme";
		else if(chaine.equals("Else")) return "SINON";
		else if(chaine.equals("Start")) return "Début d'un bloc";
		else if(chaine.equals("Finish")) return "Fin d'un bloc";
                else if(chaine.equals("Then")) return "action de boucle";
                else if(chaine.equals("EndLoop")) return "fin de boucle";
		else if(chaine.startsWith("//.")) return "un commentaire";
		else if(chaine.equals("End_Program")) return "Fin du programme";
		else if(chaine.startsWith("ShowMes :"))  return "Affichage d'un message à l'ecran";
		else if(chaine.contains(" ")) {
			mot = chaine.split(" ");
			int i=0, k=1;

				if(mot[i].equals("Int_Number")||mot[i].equals("Real_Number")){
					i++;
					if(mot[i].equals(":"))
						i++;
						if(id(mot[i]) != null){
							i++;
							while(mot[i].equals(",")){
								i++;
								k++;
								if(id(mot[i]) != null) i++;
							}
							if(mot[i].equals(";;")) return "Déclaration de "+k+" variables entiers";
						}
					

				}
				else if(mot[i].equals("Give")){
					i++;
					if(id(mot[i]) != null){
						i++;
					if(mot[i].equals(":")){
                                            i++;
						if(num(mot[i]) == "un entier") {
							i++;
							if(mot[i].equals(";;")) return "affectation dune valeur entiere à "+mot[i-2];
						}
						else if(num(mot[i]) == "un reel"){
							i++;
							if(mot[i].equals(";;")) return "affectation dune valeur reel à "+mot[i-3];
						}
                                        }

					
				}

				}
				
				else if(mot[i].equals("Real_Number")){
					i++;
					if(mot[i].equals(":"))i++;
						if(id(mot[i]) != null)i++;
							if(mot[i].equals(";;")) return "Déclaration de  variable reel";
						}


				
				
				else if(mot[i].equals("If")){
					i++;
					if(mot[i].equals("--")){
						i++;
					if(id(mot[i]) != null){
						i++;
						if(mot[i].equals("<") || mot[i].equals(">") || mot[i].equals("==")){
						i++;
						if(id(mot[i]) != null){
				                i++;
						if(mot[i].equals("--")){    
                                                i++;
                                                
                                                return "condition";                                                              
                                                }
                                                      }
                                                     
                                                } 
							
				}
                                        }
                                }
				else if(mot[i].equals("While") ||mot[i].equals("For") ){
					i++;
					if(mot[i].equals("(")){
						i++;
					if(id(mot[i]) != null){
						i++;
						if(mot[i].equals("<") || mot[i].equals(">") || mot[i].equals("==")){
						i++;
						if(id(mot[i]) != null){
				                i++;
						if(mot[i].equals(")")){    
                                                i++;
                                                
                                                return "boucle";                                                              
                                                }
                                                      }
                                                     
                                                } 
							
				}
                                        }
                                }
				
				
				
				else if(mot[i].equals("Get")){
					i++;
					if(id(mot[i]) != null){
						i++;
					if(mot[i].equals("From")){
						i++;
						if(id(mot[i]) != null) {
							i++;
							if(mot[i].equals("%.")) return "affectation de "+mot[i-3]+" a "+mot[i-1];
						}

					}
                                        }

				}
                                        else if(mot[i].equals("Affect")){
					i++;
					if(id(mot[i]) != null){
						i++;
					if(mot[i].equals("to")){
						i++;
						if(id(mot[i]) != null) {
							i++;
							if(mot[i].equals(";;")) return "affectation de valeur entre variable ";
						}

					}

				}

				}
				
				
				else if(mot[i].equals("ShowVal")){
					i++;
					if(mot[i].equals(":")){
                                            i++;
              						if(id(mot[i]) != null){
                                                        i++;
							if(mot[i].equals(";;")) return "affichage de la valeur de "+mot[i-1];
						}
                                                }
                                }

				

				
								
		
	}

                
                return "erreur de syntaxe";
        }
        
	



	public void lexicale(List<String> liste) {
		int i = 0;

		while (i < mots.size()) {
			if (UL_reserve(mots.get(i)) != null) {
				sortie_lexic.add(UL_reserve(mots.get(i)));
			} else if (id(mots.get(i)) != null) {
				sortie_lexic.add(id(mots.get(i)));
			} else if (num(mots.get(i)) != null) {
				sortie_lexic.add(num(mots.get(i)));
			}
			else sortie_lexic.add("Erreur");

			i++;
		}

	}


	
	public String semantique(String chaine){
		if(chaine.equals("Start_Program")) return "debut d un program";
		else if(chaine.equals("Else")) return "else";
		else if(chaine.equals("Start")) return "debut d un bloc";
		else if(chaine.equals("Finish")) return "fin de bloc";
                     else if(chaine.equals("Then")) return "action de boucle";
                else if(chaine.equals("EndLoop")) return "fin de boucle";
		else if(chaine.startsWith("//.")) return "ceci est un commentaire";
		else if(chaine.equals("End_Program")) return "fin de program";
		else if(chaine.startsWith("ShowMes") && chaine.endsWith(";;")) return "affichage d un message";
                else if(chaine.startsWith("ShowVal") && chaine.endsWith(";;")) return "affichage d une valeur";
		else if(chaine.contains(" ")) {
			mot = chaine.split(" ");
			int i=0;

				if(mot[i].equals("Int_Number")){
					i++;
					if(mot[i].equals(":"))
						i++;
						if(id(mot[i]) != null){
							i++;
							while(mot[i].equals(",") && i<7){
								i++;
								if(id(mot[i]) != null) i++;
							}
							if(mot[i].equals(";;"))return "declaration de entier";
						}
					

				}
				
				else if(mot[i].equals("Give")){
					i++;
					if(id(mot[i]) != null){
						i++;
					if(mot[i].equals(":"))i++;
						if(num(mot[i]) == "un entier") {
							i++;
							if(mot[i].equals(";;")) return "affectation d'une valeur entier";
						}
						else if(num(mot[i]) == "un reel"){
							i++;
							if(mot[i].equals(";;")) return "affectation valeur reel";
						}

					
				}

				}
				
				else if(mot[i].equals("Real_Number")){
					i++;
					if(mot[i].equals(":"))i++;
						if(id(mot[i]) != null)i++;
							if(mot[i].equals(";;")) return "declaration d un reel";
						}


				
				
				else if(mot[i].equals("If")){
					i++;
					if(mot[i].equals("--")){
						i++;
					if(id(mot[i]) != null){
						i++;
						if(mot[i].equals("<") || mot[i].equals(">") || mot[i].equals("==")){
						i++;
						if(id(mot[i]) != null){
							i++;
						if(mot[i].equals("--")) return "condition avec action"; 
							}}}}
				}
                                else if(mot[i].equals("While") ||mot[i].equals("For") ){
					i++;
					if(mot[i].equals("(")){
						i++;
					if(id(mot[i]) != null){
						i++;
						if(mot[i].equals("<") || mot[i].equals(">") || mot[i].equals("==")){
						i++;
						if(id(mot[i]) != null){
				                i++;
						if(mot[i].equals(")")){    
                                                i++;
                                                
                                                return "boucle";                                                              
                                                }
                                                      }
                                                     
                                                } 
							
				}
                                        }
                                }
				
				
				
				
				else if(mot[i].equals("Affect")){
					i++;
					if(id(mot[i]) != null){
						i++;
					if(mot[i].equals("to")){
						i++;
						if(id(mot[i]) != null) {
							i++;
							if(mot[i].equals(";;")) return  "affectation valeur entre variable";
						}

					}

				}

				}
				
				
				

				

				
								}
		return "erreur symantique";
		
	}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea TEXT1;
    private javax.swing.JTextArea TEXT2;
    private javax.swing.JTextArea TEXT3;
    private javax.swing.JTextArea TEXT4;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables

}
