   Ce micro projet compila analyse un fichier de l'extension compila (fichier.compila) 
et detecte si il ya des ereurs lexicale ou syntaxique ou semantique
On a fait une fonction filechooser qui permet de ramener un fichier pour le analyser
et apres on a stocke dans des tableaux les token qu'ona a besoin comme : Start_Program....ext
et on a declarer les nombre entier et reel et les identificateur
on fait plusieur condition if and else if pour comparer si le code est juste 
exp:  else if(mot[i].equals("If")){
					i++;
					if(mot[i].equals("--")){
						i++;
					if(id(mot[i]) != null){
						i++;
						if(mot[i].equals("<") || mot[i].equals(">") || mot[i].equals("==")){
						i++;
						if(id(mot[i]) != null){
				                i++;
						if(mot[i].equals("--")){    
                                                i++;
                                                
                                                return "condition";                                                              
                                               }
	ce exemple verifie si la condition If est juste
il ya trois partie dans le compilateur :
1- analyse lexicale: qui analyse caractere par caractere et affiche le mot correct sinon si
il ne le trouve pas il affiche ereure
2-analyse syntaxique :	qui analyse le code ligne par ligne et affiche ce quelle fait la ligne
sinon il return ereur syntaxique
3-analyse semantique: analyse le code ligne par ligne pour detecter les ereur symantique
											   